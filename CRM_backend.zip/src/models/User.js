const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const { ALL_ROLES, DEPARTMENTS, DEFAULT_DEPARTMENT } = require('../utils/department');

const userSchema = new mongoose.Schema({
    username: {
        type: String,
        required: [true, 'Username is required'],
        unique: true,
        trim: true,
        lowercase: true,
        minlength: [3, 'Username must be at least 3 characters']
    },
    password: {
        type: String,
        required: [true, 'Password is required'],
        minlength: [5, 'Password must be at least 5 characters'],
        select: false // Don't include password in queries by default
    },
    name: {
        type: String,
        required: [true, 'Name is required'],
        trim: true
    },
    email: {
        type: String,
        required: [true, 'Email is required'],
        unique: true,
        trim: true,
        lowercase: true,
        match: [/^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/, 'Please enter a valid email']
    },
    role: {
        type: String,
        enum: ALL_ROLES,
        default: 'salesperson'
    },
    department: {
        type: String,
        enum: DEPARTMENTS,
        default: DEFAULT_DEPARTMENT,
        index: true
    },
    branch: {
        type: String,
        trim: true
    },
    phoneNumber: {
        type: String,
        trim: true
    },
    // For sandboxed sub-accounts (role: business_sub): the salesperson this
    // sub-user acts on behalf of. Business entries they add are owned by, and
    // visible only for, this linked salesperson. Null/absent for normal users.
    linkedSalesPerson: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        default: null
    },
    isActive: {
        type: Boolean,
        default: true
    },
    lastLogin: {
        type: Date
    }
}, {
    timestamps: true
});

// Hash password before saving
userSchema.pre('save', async function(next) {
    if (!this.isModified('password')) {
        return next();
    }
    const salt = await bcrypt.genSalt(10);
    this.password = await bcrypt.hash(this.password, salt);
    next();
});

// Compare password method
userSchema.methods.comparePassword = async function(candidatePassword) {
    return await bcrypt.compare(candidatePassword, this.password);
};

// Remove sensitive data when converting to JSON
userSchema.methods.toJSON = function() {
    const user = this.toObject();
    delete user.password;
    return user;
};

module.exports = mongoose.model('User', userSchema);
