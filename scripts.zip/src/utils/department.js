// Centralised, department-aware helpers. Adding a new department in future only
// requires extending DEPARTMENTS / ROLES_BY_DEPARTMENT and (optionally) the
// FULL_ACCESS_ROLES list — controllers do not need to change.

const DEPARTMENTS = ['relocation', 'hr', 'purchase', 'finance', 'director', 'operations'];
const DEFAULT_DEPARTMENT = 'relocation';

// Roles allowed in each department (admin is shared across departments)
const ROLES_BY_DEPARTMENT = {
    relocation: ['salesperson', 'manager', 'admin'],
    hr: ['recruiter', 'team_leader', 'admin'],
    purchase: ['purchase_manager', 'branch_manager', 'warehouse_manager'],
    finance: ['finance_manager', 'accounts_executive'],
    // The Director section has no dedicated roles of its own — only the
    // cross-department Admin and Director roles may enter it.
    director: [],
    operations: ['operations_manager', 'operations_executive'],
};

// Cross-department roles. These are not tied to one department — they may
// operate anywhere, and are offered in User Management regardless of the
// department selected.
//
// `director` carries the same CRM authority as `admin`. It is added ALONGSIDE
// admin rather than replacing it: every existing admin permission is unchanged,
// and anywhere the code asks "is this an administrator?" it should call
// isAdminLevel() so both roles answer yes.
const CROSS_DEPARTMENT_ROLES = ['admin', 'director'];
const ADMIN_LEVEL_ROLES = ['admin', 'director'];

// Older HR roles kept valid in the schema so existing accounts never break,
// even though they are no longer offered at signup.
const LEGACY_ROLES = ['senior_recruiter', 'hr_executive', 'hr_manager', 'hr_head'];

// Special-purpose restricted roles. Not offered at signup — created only via
// admin scripts. `business_sub` is a temporary, sandboxed sub-account that can
// ONLY view/add Business entries on behalf of a linked salesperson.
// Removing this role (and its holders) has no effect on any other feature.
const SUBUSER_ROLES = ['business_sub'];

// All roles across departments (used for the User schema enum)
const ALL_ROLES = [...new Set([
    ...Object.values(ROLES_BY_DEPARTMENT).flat(),
    ...CROSS_DEPARTMENT_ROLES,
    ...LEGACY_ROLES,
    ...SUBUSER_ROLES,
])];

// Roles that can view all entries within their department (vs. only their own).
// All Purchase department roles manage the department's shared inventory data.
const FULL_ACCESS_ROLES = [
    'admin', 'director', 'manager', 'hr_manager', 'hr_head',
    'purchase_manager', 'branch_manager', 'warehouse_manager',
    'finance_manager', 'accounts_executive',
    'operations_manager', 'operations_executive',
];

// Vendors and their KYC are deliberately SHARED between Purchase, Operations
// and Finance — these departments work the same records rather than keeping
// duplicates. Any collection listed here is exempt from department filtering;
// access is instead controlled by role (see canEditVendors / canGenerateKycLink
// / canReviewKyc below) and, for KYC, by the form type (see canAccessKycType).
const SHARED_DEPARTMENTS = ['purchase', 'finance', 'operations'];

const PURCHASE_ROLES = ROLES_BY_DEPARTMENT.purchase;
const FINANCE_ROLES = ROLES_BY_DEPARTMENT.finance;
const OPERATIONS_ROLES = ROLES_BY_DEPARTMENT.operations;

// The two KYC workflows. A vendor's submission belongs to exactly one of them,
// recorded on the record as `kycType`. Defined in kycConstants (which owns the
// per-form configuration) and re-exported here so permission callers have one
// import; kycConstants requires nothing, so there is no cycle.
const { KYC_TYPES, DEFAULT_KYC_TYPE, isValidKycType } = require('../constants/kycConstants');

// Exactly the CRM Admin role.
const isAdmin = (user) => user?.role === 'admin';

// Admin OR Director. Use this for "does this user have administrator authority?"
// — the two roles are equivalent across the CRM by design.
const isAdminLevel = (user) => ADMIN_LEVEL_ROLES.includes(user?.role);

const isDirector = (user) => user?.role === 'director';
const isPurchaseUser = (user) => PURCHASE_ROLES.includes(user?.role);
const isFinanceUser = (user) => FINANCE_ROLES.includes(user?.role);
const isOperationsUser = (user) => OPERATIONS_ROLES.includes(user?.role);

// Who may see the shared vendor register at all
const canViewVendors = (user) =>
    isAdminLevel(user) || isPurchaseUser(user) || isFinanceUser(user) || isOperationsUser(user);

// Who may CREATE or EDIT a vendor record.
// Finance is deliberately excluded: their role is to review and verify what
// Purchase has recorded, not to alter it. Administrators still can.
const canEditVendors = (user) =>
    isAdminLevel(user) || user?.role === 'purchase_manager';

// Who may generate and share a vendor's KYC form link, for a given form type.
// Wider than editing — Finance may request a KYC from a vendor (the source
// department is recorded on the submission), they just cannot edit the record.
//
// Purchase KYC keeps exactly the set that could already generate links
// (purchase_manager, Finance, administrators) so no existing permission moves.
// Operations KYC is new, so the whole Operations team may generate one.
// Finance and administrators reach BOTH workflows.
const canGenerateKycLink = (user, kycType = DEFAULT_KYC_TYPE) => {
    if (isAdminLevel(user) || isFinanceUser(user)) return true;
    if (kycType === 'operations') return isOperationsUser(user);
    return user?.role === 'purchase_manager';
};

/**
 * Who may generate a Correction KYC Link after Finance sends a KYC back: the
 * department that owns that workflow, and administrators. Finance sends a KYC
 * back but does not generate the correction — the owning department decides
 * which details the vendor resubmits.
 */
const canGenerateCorrectionLink = (user, kycType = DEFAULT_KYC_TYPE) => {
    if (isAdminLevel(user)) return true;
    if (kycType === 'operations') return isOperationsUser(user);
    return user?.role === 'purchase_manager';
};

/**
 * Who may view / track submissions of a given KYC type.
 * Purchase staff see Purchase KYC, Operations staff see Operations KYC;
 * Finance and administrators see both. Mirrors canGenerateKycLink so a user
 * cannot read a workflow they could not have started.
 */
const canAccessKycType = (user, kycType) => {
    if (isAdminLevel(user) || isFinanceUser(user)) return true;
    if (kycType === 'operations') return isOperationsUser(user);
    if (kycType === 'purchase') return isPurchaseUser(user);
    return false;
};

/**
 * The KYC types this user may work with — used to scope vendor listings so
 * Purchase never sees Operations submissions and vice versa.
 * Returns null when the user is unrestricted (Finance / administrators).
 */
const kycTypesForUser = (user) => {
    if (isAdminLevel(user) || isFinanceUser(user)) return null;
    if (isOperationsUser(user)) return ['operations'];
    if (isPurchaseUser(user)) return ['purchase'];
    return [];
};

/**
 * Which KYC types a vendor LISTING should return for this request.
 *
 * Two things narrow the result, in order:
 *
 *   1. Role — Purchase staff only ever see Purchase KYC, Operations staff only
 *      Operations KYC. This is the security boundary and cannot be widened.
 *   2. The department section being browsed. Finance and administrators are
 *      unrestricted by role, but opening the Purchase Department should show
 *      Purchase KYC, not both. The client sends the active department on every
 *      request, so the same account sees the right records in each section and
 *      still reaches everything by switching section.
 *
 * An explicit ?kycType= may narrow further, never widen.
 *
 * @returns {string[]|null} the permitted types, or null for "no restriction"
 */
const kycScopeForRequest = (req) => {
    const allowed = kycTypesForUser(req.user);          // null = unrestricted

    const narrow = (type) => {
        // Only ever a narrowing: a caller may not reach a type their role bars
        if (!isValidKycType(type) || !canAccessKycType(req.user, type)) return allowed;
        if (allowed && !allowed.includes(type)) return allowed;
        return [type];
    };

    // An explicit filter wins over the ambient department
    const asked = req.query?.kycType;
    if (isValidKycType(asked)) return narrow(asked);

    // Otherwise follow the section being browsed. 'finance' deliberately does
    // not narrow — Finance reviews both workflows side by side.
    const browsing = req.query?.department || req.body?.department;
    if (browsing === 'purchase' || browsing === 'operations') return narrow(browsing);

    return allowed;
};

/**
 * Turn a scope into a Mongo filter fragment. Records created before the
 * Operations split carry no kycType and count as Purchase.
 */
const kycTypeQuery = (scope) => {
    if (!scope) return {};                               // unrestricted
    if (!scope.length) return { kycType: { $in: [] } };  // nothing visible
    return scope.includes('purchase')
        ? { kycType: { $in: [...scope, null] } }
        : { kycType: { $in: scope } };
};

// Kept as an alias so nothing that already imported it breaks. Prefer the two
// specific helpers above — they say which action is being authorised.
const canManageVendors = canEditVendors;

// Finance is the ONLY department that may approve or reject a KYC submission.
// Purchase users — including Purchase Managers — are deliberately excluded.
const canReviewKyc = (user) => isAdminLevel(user) || isFinanceUser(user);

// Purchase Orders are owned by the Purchase Manager (and administrators).
const canManagePurchaseOrders = (user) => isAdminLevel(user) || user?.role === 'purchase_manager';

// --- Rate Comparison authority ---------------------------------------------

// Purchase staff prepare rate comparisons; administrators may too.
const canManageRateComparisons = (user) => isAdminLevel(user) || isPurchaseUser(user);

// Only the Director (or an Admin, who shares the same authority) may approve,
// reject or send back a rate comparison. Purchase staff cannot approve their own.
const canApproveRateComparisons = (user) => isAdminLevel(user);

const isValidDepartment = (d) => DEPARTMENTS.includes(d);

// True when the role may view department-wide data (not just their own records)
const canViewAllInDepartment = (role) => FULL_ACCESS_ROLES.includes(role);

// Resolve the department a request should operate on.
// - Admins may target any department via ?department= or body.department
// - Everyone else is locked to their own department (param ignored for safety)
const resolveDepartment = (req) => {
    const own = req.user?.department || DEFAULT_DEPARTMENT;
    // Administrators (Admin and Director) may switch departments freely
    if (ADMIN_LEVEL_ROLES.includes(req.user?.role)) {
        const requested = req.query?.department || req.body?.department;
        return isValidDepartment(requested) ? requested : own;
    }
    return own;
};

// Mongo filter fragment for a department. The legacy "relocation" department also
// absorbs documents created before departments existed (null / missing field).
const departmentQuery = (department) => {
    if (department === DEFAULT_DEPARTMENT) {
        return { department: { $in: [DEFAULT_DEPARTMENT, null] } };
    }
    return { department };
};

module.exports = {
    DEPARTMENTS,
    DEFAULT_DEPARTMENT,
    ROLES_BY_DEPARTMENT,
    SUBUSER_ROLES,
    ALL_ROLES,
    FULL_ACCESS_ROLES,
    SHARED_DEPARTMENTS,
    CROSS_DEPARTMENT_ROLES,
    ADMIN_LEVEL_ROLES,
    PURCHASE_ROLES,
    FINANCE_ROLES,
    OPERATIONS_ROLES,
    KYC_TYPES,
    DEFAULT_KYC_TYPE,
    isValidKycType,
    isValidDepartment,
    canViewAllInDepartment,
    resolveDepartment,
    departmentQuery,
    isAdmin,
    isAdminLevel,
    isDirector,
    isPurchaseUser,
    isFinanceUser,
    isOperationsUser,
    canViewVendors,
    canEditVendors,
    canGenerateKycLink,
    canGenerateCorrectionLink,
    canAccessKycType,
    kycTypesForUser,
    kycScopeForRequest,
    kycTypeQuery,
    canManageVendors,
    canReviewKyc,
    canManagePurchaseOrders,
    canManageRateComparisons,
    canApproveRateComparisons,
};
