const express = require('express');
const cors = require('cors');
const errorHandler = require('./middleware/errorHandler');

// Import routes
const authRoutes = require('./routes/authRoutes');
const salesRoutes = require('./routes/salesRoutes');
const followUpRoutes = require('./routes/followUpRoutes');
const notificationRoutes = require('./routes/notificationRoutes');
const dashboardRoutes = require('./routes/dashboardRoutes');
const branchRoutes = require('./routes/branchRoutes');
const businessRoutes = require('./routes/businessRoutes');
const recruitmentRoutes = require('./routes/recruitmentRoutes');
const purchaseRoutes = require('./routes/purchaseRoutes');
const vendorRoutes = require('./routes/vendorRoutes');
const purchaseOrderRoutes = require('./routes/purchaseOrderRoutes');
const kycRoutes = require('./routes/kycRoutes');
const rateComparisonRoutes = require('./routes/rateComparisonRoutes');

// Load the Cloudinary service early so its "not configured" warning appears at
// boot rather than on the first KYC upload attempt.
require('./services/cloudinaryService');

// Initialize express app
const app = express();

// ============================================
// MIDDLEWARE
// ============================================

// CORS — simple and permissive.
// `origin: true` reflects whatever Origin made the request (required instead of
// '*' because we send credentials). By NOT listing `methods` or `allowedHeaders`,
// the cors package automatically mirrors back whatever the browser asks for in
// its preflight — so every method and every header (including x-auth-access-key)
// is allowed with no maintenance. This also handles OPTIONS preflight for us.
app.use(cors({
    origin: true,
    credentials: true,
    exposedHeaders: ['X-Total-Records'] // let the browser read the export row count
}));

// Body parser middleware. The old 50mb ceiling existed only for base64 image
// uploads (Sales Visit); 1mb is ample for JSON payloads and limits abuse.
app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ extended: true, limit: '1mb' }));

// Request logging in development
if (process.env.NODE_ENV === 'development') {
    app.use((req, res, next) => {
        console.log(`${new Date().toISOString()} - ${req.method} ${req.path}`);
        next();
    });
}

// ============================================
// ROUTES
// ============================================

// Health check endpoint
app.get('/api/health', (req, res) => {
    res.status(200).json({
        success: true,
        message: 'OmTrax CRM API is running',
        timestamp: new Date().toISOString(),
        environment: process.env.NODE_ENV
    });
});

// API Routes
app.use('/api/auth', authRoutes);
app.use('/api/sales', salesRoutes);
app.use('/api/follow-ups', followUpRoutes);
app.use('/api/notifications', notificationRoutes);
app.use('/api/dashboard', dashboardRoutes);
app.use('/api/branches', branchRoutes);
app.use('/api/business', businessRoutes);
app.use('/api/recruitment', recruitmentRoutes);
app.use('/api/purchase', purchaseRoutes);
app.use('/api/vendors', vendorRoutes);
app.use('/api/purchase-orders', purchaseOrderRoutes);
app.use('/api/rate-comparisons', rateComparisonRoutes);

// PUBLIC — the vendor KYC form has no CRM login. Authorisation is the one-time
// token in the URL. Mounted last among the API routes so nothing shadows it.
app.use('/api/kyc', kycRoutes);

// ============================================
// ERROR HANDLING
// ============================================

// Handle 404 - Route not found
app.use((req, res, next) => {
    res.status(404).json({
        success: false,
        message: `Route ${req.originalUrl} not found`
    });
});

// Global error handler
app.use(errorHandler);

module.exports = app;
